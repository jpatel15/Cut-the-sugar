package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bean.AppointmentBean;
import com.bean.DoctorBean;
import com.bean.RegistrationBean;

import util.Dbconnection;

public class DoctorModel {
	public static int addDoctor(DoctorBean user) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
int i=0;
		String sql = "insert into Doctor_Details ("
				+ "Dr_name,Dr_Mobile_number,dr_gender,dr_email,dr_username,dr_password,Dr_specif"
				+ ",Qualification,HsName) values ("
				+ "?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getFname()+"  "+user.getLname());
			ps.setString(2, user.getMob_number());
			ps.setString(3, user.getGender());
			ps.setString(4, user.getEmail());
			ps.setString(5, user.getEmail());
			ps.setString(6, user.getPassword());
			ps.setString(7, user.getSpec());
			ps.setString(8, user.getQualif());
			ps.setString(9, user.getHsName());

			i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			i=0;
			
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	return i;
	}

	public static DoctorBean findUser(String userid) {

		DoctorBean user = new DoctorBean();

		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		/*String sql = "insert into Doctor_Details ("
				+ "Dr_name,Dr_Mobile_number,dr_gender,dr_email,dr_username,dr_password,Dr_specif"
				+ ",Qualification) values ("
				+ "?,?,?,?,?,?,?,?)";*/
	
		String sql = "select * from Doctor_Details where dr_email =?";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, userid);
			ResultSet rs = ps.executeQuery();
			rs.next();

				user.setEmail(rs.getString("dr_email"));
				user.setPassword(rs.getString("dr_password"));
				String[] name=rs.getString("Dr_name").split("  ");
				user.setFname(name[0]);
				user.setLname(name[1]);
				user.setGender(rs.getString("dr_gender"));
				user.setMob_number(rs.getString("Dr_Mobile_number"));
				user.setDr_id(rs.getInt("Dr_id"));
				user.setSpec(rs.getString("Dr_specif"));
				user.setQualif(rs.getString("Qualification"));
				user.setHsName(rs.getString("HsName"));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return user;
	}

/**
	 * 
	 * 
	 * @param user
	 */
	public static int updateDoctorProfile(DoctorBean user) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
int i=0;
/*String sql = "insert into Doctor_Details ("
				+ "Dr_name,Dr_Mobile_number,dr_gender,dr_email,dr_username,dr_password,Dr_specif"
				+ ",Qualification) values ("
				+ "?,?,?,?,?,?,?,?)";*/

		String sql = "update Doctor_Details set Dr_name=?, Dr_Mobile_number=?,dr_gender=?, "
				+ "Dr_specif=?, Qualification=?,HsName=? where dr_email=? && dr_id=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getFname()+"  "+user.getLname());
			ps.setString(2, user.getMob_number());
			ps.setString(3, user.getGender());
			ps.setString(4, user.getSpec());
			ps.setString(5, user.getQualif());
			ps.setString(6, user.getHsName());
			ps.setString(7, user.getEmail());
			ps.setInt(8, user.getDr_id());
			i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
return i;
	}
	
	public static int updateDrPass(DoctorBean user) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
int i=0;
/*String sql = "insert into Doctor_Details ("
				+ "Dr_name,Dr_Mobile_number,dr_gender,dr_email,dr_username,dr_password,Dr_specif"
				+ ",Qualification) values ("
				+ "?,?,?,?,?,?,?,?)";*/

String sql = "update Doctor_Details set Dr_name=?, Dr_Mobile_number=?,dr_gender=?, "
		+ "Dr_specif=?, Qualification=?,HsName=? ,dr_password=? where dr_email=? && dr_id=?";
try {
	PreparedStatement ps = con.prepareStatement(sql);
	ps.setString(1, user.getFname()+"  "+user.getLname());
	ps.setString(2, user.getMob_number());
	ps.setString(3, user.getGender());
	ps.setString(4, user.getSpec());
	ps.setString(5, user.getQualif());
	ps.setString(6, user.getHsName());
	ps.setString(7, user.getPassword());
	ps.setString(8, user.getEmail());
	ps.setInt(9, user.getDr_id());
	i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
return i;
	}

	public static List<DoctorBean> getDrList() {
		List<DoctorBean> users = new ArrayList<>();

		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			Statement st = con.createStatement();
			/*String sql = "insert into Doctor_Details ("
			+ "Dr_name,Dr_Mobile_number,dr_gender,dr_email,dr_username,dr_password,Dr_specif"
			+ ",Qualification) values ("
			+ "?,?,?,?,?,?,?,?)";*/

	String sql = "select * from Doctor_Details join dr_availibility on Doctor_Details.Dr_id =dr_availibility.Dr_id";


			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {

				String P_name = rs.getString("Dr_name");
				String P_mobile_number = rs.getString("Dr_specif");
				String P_gender = rs.getString("Qualification");
				String P_Email = rs.getString("dr_email");
					String dates=rs.getDate("Dr_a_date").toString();
				String[] name=P_name.split("  ");

				DoctorBean user = new DoctorBean();
				user.setEmail(P_Email);
				user.setQualif(P_gender);
				user.setSpec(P_mobile_number);
				user.setFname(name[0]);
				user.setLname(name[1]);
				user.setDate(dates);
				
				users.add(user);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return users;
	}

}
