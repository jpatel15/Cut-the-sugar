package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bean.PataintBean;
import com.bean.Report;

import util.Dbconnection;

public class ReportModule {

	public int addreport(Report report) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int i=0;
		String sql = "insert into Report ("
				+ "bloodGroup,speciality,type,P_id) values ("
				+ "?,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, report.getBloodGroup());
			ps.setString(2, report.getSpeciality());
			ps.setString(3, report.getType());
			ps.setInt(4, report.getPid());
			
			i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
		//	i=0;
			
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	return i;
}

	public int updatereport(Report report) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		int i=0;
		String sql = "update  Report set "
				+ "bloodGroup=?,speciality=?,type=? where r_id=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, report.getBloodGroup());
			ps.setString(2, report.getSpeciality());
			ps.setString(3, report.getType());
			ps.setInt(4, report.getR_id());
			i = ps.executeUpdate();
			
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			i=0;
			
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	return i;
	}

	public  Report findreport(int pid) {
Report user = new Report();
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			Statement st = con.createStatement();
			String sql = "select * from Report where p_id="+pid;
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {

				String bg = rs.getString("bloodGroup");
				String type = rs.getString("type");
				String speciality = rs.getString("speciality");
int r_id= rs.getInt("r_id");
//				int idp=rs.getInt("status");

				user.setBloodGroup(bg);
				user.setPid(pid);
				user.setR_id(r_id);
				user.setSpeciality(speciality);
				user.setType(type);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return user;
	}

}
