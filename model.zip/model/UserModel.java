package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bean.RegistrationBean;


import util.Dbconnection;

public class UserModel {

	/**
	 * 
	 * 
	 * @param user
	 */
	
	public static int addUser(RegistrationBean user) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
int i=0;
		String sql = "insert into Registration ("
				+ "First_name,Last_name,mobile_number,gender,DOB,Email,username,password) values ("
				+ "?,?,?,?,null,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getFname());
			ps.setString(2, user.getLname());
			ps.setString(3, user.getMob_number());
			ps.setString(4, user.getGender());
			//ps.setString(5, user.get());
			ps.setString(5, user.getEmail());
			ps.setString(6, user.getEmail());
			ps.setString(7, user.getPassword());
			//ps.setString(8, user.getLname());

			i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			i=0;
			
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	return i;
	}


	/**
	 * 
	 * 
	 * @return
	 *//*
	public static List<User> getUsers() {
		List<User> users = new ArrayList<User>();

		Connection con = DBConnector.getConnection();
		try {
			Statement st = con.createStatement();
			String sql = "select * from user";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {

				String username = rs.getString("username");
				String password = rs.getString("password");
				int userid = rs.getInt("userid");

				User user = new User();
				user.setPassword(password);
				user.setUserid(userid);
				user.setUsername(username);
				// add single -single user objects in collections
				users.add(user);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return users;
	}

	
	*//**
	 * 
	 * 
	 * @param userid
	 * @return
	 */

	public static RegistrationBean findUser(String userid) {

		RegistrationBean user = new RegistrationBean();

		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		/*String sql1 = "insert into Registration ("
				+ "First_name,Last_name,mobile_number,gender,DOB,Email,username,password) values ("
				+ "?,?,?,?,null,?,?,?)";*/
	
		String sql = "select * from Registration where Email =?";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, userid);
			ResultSet rs = ps.executeQuery();
			rs.next();

				user.setEmail(rs.getString("Email"));
				user.setPassword(rs.getString("password"));
				user.setFname(rs.getString("First_name"));
				user.setLname(rs.getString("Last_name"));
				user.setGender(rs.getString("gender"));
				user.setMob_number(rs.getString("mobile_number"));
				user.setReg_id(rs.getInt("Reg_id"));

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return user;
	}

/**
	 * 
	 * 
	 * @param user
	 */
	public static int updateUser(RegistrationBean user) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
int i=0;
/*String sql1 = "insert into Registration ("
+ "First_name,Last_name,mobile_number,gender,DOB,Email,username,password) values ("
+ "?,?,?,?,null,?,?,?)";*/

		String sql = "update Registration set First_name=?, Last_name=?,mobile_number=?, "
				+ "gender=? where Email=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getFname());
			ps.setString(2, user.getLname());
			ps.setString(3, user.getMob_number());
			ps.setString(4, user.getGender());
			ps.setString(5, user.getEmail());
			i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
return i;
	}
	
	public static int updateUserPass(RegistrationBean user) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
int i=0;
/*String sql1 = "insert into Registration ("
+ "First_name,Last_name,mobile_number,gender,DOB,Email,username,password) values ("
+ "?,?,?,?,null,?,?,?)";*/

		String sql = "update Registration set First_name=?, Last_name=?,mobile_number=?, "
				+ "gender=? ,password=? where Email=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getFname());
			ps.setString(2, user.getLname());
			ps.setString(3, user.getMob_number());
			ps.setString(4, user.getGender());
			ps.setString(5, user.getPassword());
			ps.setString(6, user.getEmail());
			i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
return i;
	}

	/**
	 * 
	 * 
	 * @param userid
	 *//*
	public static int deleteUser(String userid) {
		// TODO Auto-generated method stub
		Connection con = Dbconnection.getcon()
				;
int i=0;
		String sql = "delete from user where userid=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, userid);
			
			int i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
return i;
	}

}
*/
	}