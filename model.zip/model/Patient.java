package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bean.PataintBean;

import util.Dbconnection;

public class Patient {

	public static List<PataintBean> getReports() {
		List<PataintBean> users = new ArrayList<>();

		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			Statement st = con.createStatement();
			String sql = "select * from pataint_details";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {

				String P_name = rs.getString("P_name");
				String P_mobile_number = rs.getString("P_mobile_number");
				String P_gender = rs.getString("P_gender");
				String P_Email = rs.getString("P_Email");

				int idp=rs.getInt("status");
				PataintBean user = new PataintBean();
				user.setP_Email(P_Email);
				user.setP_gender(P_gender);
				user.setP_mobile_number(P_mobile_number);
				user.setP_name(P_name);
				user.setP_id(rs.getInt("P_id"));
				// add single -single user objects in collections
				user.setStatus(idp);
				
				users.add(user);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return users;
	}

	public static int addPDetails(PataintBean user) {
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
int i=0;
		String sql = "insert into Pataint_Details ("
				+ "P_name,P_mobile_number,P_gender,P_Email,P_DOB,P_Username,P_password) values ("
				+ "?,?,?,?,null,null,null)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getP_name());
			ps.setString(2, user.getP_mobile_number());
			ps.setString(3, user.getP_gender());
			ps.setString(4, user.getP_Email());
			//ps.setString(8, user.getLname());

			i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			i=0;
			
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	return i;
	}

	

}
