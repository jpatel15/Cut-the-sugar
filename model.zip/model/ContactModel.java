package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import com.bean.AppointmentBean;
import com.bean.ContactFormBean;

import util.Dbconnection;

public class ContactModel {

	public static int  bookContactForm(ContactFormBean user) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int i=0;
		String sql = "insert into contact_form ("
				+ "email,name,phone,message) values ("
				+ "?,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getEmail());
			ps.setString(2, user.getName());
			ps.setString(3, user.getPhone());
			ps.setString(4, user.getMessage());
			//ps.setString(8, user.getLname());

			i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			i=0;
			
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	return i;

		
	}

}
