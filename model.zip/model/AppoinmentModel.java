package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import Vo.countryVo;

import com.bean.AppointmentBean;
import com.bean.PataintBean;

import util.Dbconnection;

public class AppoinmentModel {

	public int bookAppoinment(AppointmentBean user) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
int i=0;
		String sql = "insert into appointment ("
				+ "dr_id,email,name,mob_number,message,appdate,gender,status) values ("
				+ "?,?,?,?,?,?,?,1)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getEmail());
			ps.setString(2, user.getName());
			ps.setString(3, user.getMob_number());
			ps.setString(4, user.getMessage());
			ps.setDate(5, new Date(new SimpleDateFormat("MM/DD/YYYY").parse(user.getAppdate()).getTime()));
			ps.setString(6, user.getDr_id());
			ps.setString(7, user.getGender());
			//ps.setString(8, user.getLname());

			i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}
			sql = "select app_id from appointment where email=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, user.getEmail());
			ResultSet rs=ps.executeQuery();
			rs.next();
			i=rs.getInt("app_id");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			i=0;
			
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	return i;

}
	
	public int reject(int id) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
int i=0;
		String sql = "update appointment set status =2 where app_id=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			i=0;
			
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	return i;

		
	}

	

	
	public int accept(int id) {
		// TODO Auto-generated method stub
		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
int i=0;
String sql = "update appointment set status =1 where app_id=?";
try {
	PreparedStatement ps = con.prepareStatement(sql);
	ps.setInt(1, id);
	i = ps.executeUpdate();
	
			if (i > 0) {
				System.out.println("Success Message");
			} else {
				System.out.println("Fail");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			i=0;
			
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	return i;

		
	}

	
	public static List<AppointmentBean> getAppoinmentsList() {
		List<AppointmentBean> users = new ArrayList<>();

		Connection con=null;
		try {
			con = Dbconnection.getcon();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			Statement st = con.createStatement();
			String sql = "select * from appointment , pataint_details";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {

				String P_name = rs.getString("P_name");
				String P_mobile_number = rs.getString("P_mobile_number");
				String P_gender = rs.getString("P_gender");
				String P_Email = rs.getString("P_Email");
				int p_id= rs.getInt("P_id");
				
				int app_id = rs.getInt("app_id");
				String apptime = rs.getString("apptime");
				String gender = rs.getString("gender");
				String name = rs.getString("name");
				
				int reg_id = rs.getInt("reg_id");
				String dr_id = rs.getString("dr_id");
				String appdate = rs.getString("appdate");
				String mob_number = rs.getString("mob_number");
				String message = rs.getString("message");
				String email = rs.getString("email");
				
				int status = rs.getInt("status");
				

				AppointmentBean user = new AppointmentBean();
				user.setP_Email(P_Email);
				user.setP_gender(P_gender);
				user.setP_mobile_number(P_mobile_number);
				user.setP_name(P_name);
				user.setP_id(p_id);
				
				user.setApp_id(app_id);
				user.setApptime(apptime);
				user.setGender(gender);
				user.setName(name);
				
				user.setReg_id(reg_id);
				user.setDr_id(dr_id);
				user.setAppdate(appdate);
				user.setMob_number(mob_number);
				user.setMessage(message);
				user.setEmail(email);
				user.setResponse(rs.getString("response"));
				user.setStatus(status);
				
				users.add(user);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return users;
	}

	public List searchDr_id(AppointmentBean appointmentBean) {
		// TODO Auto-generated method stub
		return null;
	}


}
