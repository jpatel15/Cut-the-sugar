package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.Dbconnection;

public class CheckPass {
	
	/*public static RegistrationBean findUser(String userid) {

		RegistrationBean user = new RegistrationBean();

		Connection con = Dbconnection.getcon();
		String sql = "select * from user where userid =?";

		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, userid);
			ResultSet rs = ps.executeQuery();
			rs.next();

				String username = rs.getString("username");
				String password = rs.getString("password");

				user.setPassword(password);
				user.setUserid(userid);
				user.setUsername(username);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return user;
	}
*/
	public boolean checkLog(String emailid,String Pass)
	{
		ResultSet rs;
		try {
			Statement statement=Dbconnection.getcon().createStatement();
			rs = statement.executeQuery("select email,username,password from registration where email='"+emailid+"'");
			while(rs.next())
			{
				if(rs.getString("email").equals(emailid))
				{
					if(rs.getString("password").equals(Pass))
					{
						return true;
					}
					else
						return false;
				}
				else
					return false;
			}
			
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public boolean checkLogDoctor(String emailid,String Pass)
	{
		ResultSet rs;
		try {
			Statement statement=Dbconnection.getcon().createStatement();
			rs = statement.executeQuery("select dr_email,dr_password from Doctor_Details where dr_email='"+emailid+"'");
			while(rs.next())
			{
				if(rs.getString("dr_email").equals(emailid))
				{
					if(rs.getString("dr_password").equals(Pass))
					{
						return true;
					}
					else
						return false;
				}
				else
					return false;
			}
			
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}


}
