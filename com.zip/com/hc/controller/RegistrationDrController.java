package com.hc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.DoctorBean;
import com.bean.RegistrationBean;

import model.DoctorModel;
import model.UserModel;

/**
 * Servlet implementation class RegistrationDrController
 */
public class RegistrationDrController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationDrController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	doGet(request, response);
		String submit = request.getParameter("submit");

		if (submit.equalsIgnoreCase("Register")) {

			String username = request.getParameter("email_id");
			String password = request.getParameter("password");
			String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			String mob_number = request.getParameter("mobile");
			String gender = request.getParameter("gender");
			String hsName = request.getParameter("hsName");
			String spec = request.getParameter("spec");
			String qualif = request.getParameter("qualif");
			

			DoctorBean user = new DoctorBean();
			user.setEmail(username);
			user.setPassword(password);
			user.setFname(fname);
			user.setLname(lname);
			user.setMob_number(mob_number);
			user.setGender(gender);
			user.setHsName(hsName);
			user.setSpec(spec);
			user.setQualif(qualif);
			

			// Database Insertt Code
		int i=	DoctorModel.addDoctor(user);
if(i>0){
	request.setAttribute("resdr", "Congress you are successfully registerd !!");
	request.getRequestDispatcher("doctorPanel.jsp").forward(request, response);

}else{
	request.setAttribute("resdr", "Some error occure , plz try again !!");
	request.getRequestDispatcher("registerDoctor.jsp").forward(request, response);
}
			
//date 
/*
SimpleDateFormat   dateFormat= new SimpleDateFormat("yyyy-MM-dd");
java.sql.Date date= new java.sql.Date(dateFormat.parse("1016-02-16").getTime()); 
	
	Statement statement= connection.createStatement();
	String sql="insert into dt( Datei) values ( "+(java.sql.Date)date+")";
	//statement.executeUpdate(sql);
	 * 
	 * 
	 * INSERT INTO TABLE_NAME(
date_column
)values(
TO_DATE('06/06/2006', 'mm/dd/yyyy')
)
	 * 
	 * 

If the field is of type datetime or timestamp, you have to use
pstmt.setDate( 1, new java.sql.Date( d1.getTime() );
pstmt.setTimestamp( 1, new java.sql.Timestamp( d1.getTime() );

	
	PreparedStatement preparedStatement= connection.prepareStatement("insert into dt( Datei) values ( ?)");
	preparedStatement.setDate(1,date);
	preparedStatement.executeUpdate();
	
*/
			
		}

		if (submit.equalsIgnoreCase("Update")) {
			int userid = Integer.parseInt(request.getParameter("dr_id"));
			String username = request.getParameter("email_id");
			String password = request.getParameter("password");
			String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			String mob_number = request.getParameter("mobile");
			String gender = request.getParameter("gender");
			String hsName = request.getParameter("hsName");
			String spec = request.getParameter("spec");
			String qualif = request.getParameter("qualif");
			

			DoctorBean user = new DoctorBean();
			user.setEmail(username);
			user.setPassword(password);
			user.setFname(fname);
			user.setLname(lname);
			user.setMob_number(mob_number);
			user.setGender(gender);
			user.setHsName(hsName);
			user.setSpec(spec);
			user.setQualif(qualif);
			user.setDr_id(userid);

			// Database Insertt Code

			int i=0;
			if(password==null ||password.trim().equals("")){
				i=DoctorModel.updateDoctorProfile(user);}
			else{user.setPassword(password);
				i=DoctorModel.updateDrPass(user);}
			if(i>0){
				request.setAttribute("resdr", "Congress you are successfully updated !!");
				request.getRequestDispatcher("ViewAppointment.jsp").forward(request, response);

			}else{
				request.setAttribute("resdr", "Some error occure , plz try again !!");
			//	request.getRequestDispatcher("dr_profile.jsp").forward(request, response);
				request.getRequestDispatcher("doctorPanel.jsp").forward(request, response);
			}

		}

		if (submit.equalsIgnoreCase("EDIT")) {

			String userid = (request.getParameter("email_id"));

		/*	RegistrationBean user = UserModel.findUser(userid);

			request.setAttribute("user", user);

		*/	request.getRequestDispatcher("index.jsp")//pass to profile page
					.forward(request, response);
		}

		if (submit.equalsIgnoreCase("DELETE")) {

			String userid = request.getParameter("email_id");

			int i=0;
				//i=	UserModel.deleteUser(userid);

			if(i>0){
				request.setAttribute("res", "successfully Deleted !!");
				request.getRequestDispatcher("login.jsp").forward(request, response);//show page

			}else{
				request.setAttribute("res", "Some error occure , plz try again to delete  !!");
				request.getRequestDispatcher("login.jsp").forward(request, response); //delete page
			}


		}
		/*if (submit.equalsIgnoreCase("SHOW")) {

			request.setAttribute("users", UserModel.getUsers());
			request.getRequestDispatcher("show.jsp").forward(request, response);

		}*/


	}

}
