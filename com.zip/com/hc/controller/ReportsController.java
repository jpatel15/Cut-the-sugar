package com.hc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.PataintBean;
import com.bean.RegistrationBean;
import com.bean.Report;

import model.AppoinmentModel;
import model.Patient;
import model.ReportModule;
import model.UserModel;

/**
 * Servlet implementation class ReportsController
 */
public class ReportsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReportsController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
		String submit = request.getParameter("req");
		int appid =Integer.parseInt( request.getParameter("pid"));
		AppoinmentModel appoinmentModel=new AppoinmentModel(); 
		if (submit.equalsIgnoreCase("add")) {
			String bloodGroup = request.getParameter("bloodGroup");
			String type = request.getParameter("type");
			String speciality = request.getParameter("speciality");
			
			Report report= new Report();
			report.setBloodGroup(bloodGroup);
			report.setPid(appid);
			report.setType(type);
			report.setSpeciality(speciality);
			
			ReportModule module= new ReportModule();
			int i=	module.addreport(report);
			if(i>0){
				appoinmentModel.accept(appid);
			}
		request.getRequestDispatcher("DrreportsFiles.jsp").forward(request, response);
		
		}else if (submit.equalsIgnoreCase("update")) {
			String bloodGroup = request.getParameter("bloodGroup");
			String type = request.getParameter("type");
			String speciality = request.getParameter("speciality");
			int rid =Integer.parseInt( request.getParameter("rid"));

			
			Report report= new Report();
			report.setBloodGroup(bloodGroup);
			report.setPid(appid);
			report.setType(type);
			report.setSpeciality(speciality);
			report.setR_id(rid);
			
			ReportModule module= new ReportModule();
			int i=	module.updatereport(report);

			request.getRequestDispatcher("DrreportsFiles.jsp").forward(request, response);
		
		}
		
		
		
		else 	if (submit.equalsIgnoreCase("reject")) {
			int app_id=	appoinmentModel.reject(appid);
			request.getRequestDispatcher("DrreportsFiles.jsp").forward(request, response);
			
		}else{

		doPost(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		String submit = request.getParameter("submit");

		if (submit.equalsIgnoreCase("Submit Details")) {

			String username = request.getParameter("email_id");
			String name = request.getParameter("firstName");
			String mob_number = request.getParameter("mobile");
			String gender = request.getParameter("gender");
			

			PataintBean user = new PataintBean();
			user.setP_Email(username);
			user.setP_name(name);
			user.setP_mobile_number(mob_number);
			user.setP_gender(gender);

			// Database Insertt Code
		int i=	Patient.addPDetails(user);
		if(i>0){
	request.setAttribute("res", "Congress you are successfully registerd !!");
	request.getRequestDispatcher("reportFiles.jsp").forward(request, response);

}else{
	request.setAttribute("res", "Some error occure , plz try again !!");
	request.getRequestDispatcher("reports.jsp").forward(request, response);
}
		}
	}
	

}
