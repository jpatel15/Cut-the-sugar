package com.hc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.CheckPass;

/**
 * Servlet implementation class LoginDrController
 */
public class LoginDrController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginDrController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession ses=request.getSession();
		String email=	ses.getAttribute("Email_Id").toString();
			
			if(request.getParameter("Email_Id")!=null &&request.getParameter("Email_Id").equals(email) ){
				ses.setAttribute("Email_Id", null);
				ses.invalidate();
				response.sendRedirect("login.jsp");
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	doGet(request, response);
		HttpSession ses=request.getSession();
		if((new CheckPass().checkLogDoctor(request.getParameter("email_id"), request.getParameter("password"))))
		{
			System.out.println("Logged In");
			ses.setAttribute("Email_Id", request.getParameter("email_id"));
			RequestDispatcher rd=request.getRequestDispatcher("dr_profile.jsp");
			request.setAttribute("res", "successfully login !!");
			rd.forward(request, response);
		}
		else
		{
			
				request.setAttribute("res", "username password incorrect , plz try again !!");
				request.getRequestDispatcher("doctorPanel.jsp").forward(request, response);
						System.out.println("Failed");
		}
		

	}

}
