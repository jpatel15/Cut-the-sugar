package com.hc.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.countryDao;
import Vo.countryVo;

import com.bean.AppointmentBean;
import com.bean.RegistrationBean;

import model.AppoinmentModel;
import model.UserModel;

/**
 * Servlet implementation class AppointmentController
 */
public class AppointmentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AppointmentController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String submit = request.getParameter("req");
		int appid =Integer.parseInt( request.getParameter("appid"));
		AppoinmentModel appoinmentModel=new AppoinmentModel(); 
		if (submit.equalsIgnoreCase("accept")) {
			
			int app_id=	appoinmentModel.accept(appid);
		request.getRequestDispatcher("ViewAppointment.jsp").forward(request, response);
		
		}else 	if (submit.equalsIgnoreCase("reject")) {
			int app_id=	appoinmentModel.reject(appid);
			request.getRequestDispatcher("ViewAppointment.jsp").forward(request, response);
			
		}

	

	
		
	}

	private void loadcountry(HttpServletRequest request, HttpServletResponse response) throws IOException {
		// TODO Auto-generated method stub
		AppointmentBean AppointmentBean =new AppointmentBean();
		
		AppoinmentModel AppoinmentModel=new AppoinmentModel();
		List ls=AppoinmentModel.searchDr_id(AppointmentBean);
		HttpSession session = request.getSession();
		
		session.setAttribute("List", ls);		
	
		
		response.sendRedirect("book-a-test.jsp");
	}
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	doGet(request, response);
		String submit = request.getParameter("submit");

		if (submit.equalsIgnoreCase("Submit Now")) {

			String username = request.getParameter("email_id");
			String name = request.getParameter("name");
			String dr_id = request.getParameter("dr_id");
			String dateselect = request.getParameter("dateselect");
			String mob_number = request.getParameter("mobile_number");
			String message = request.getParameter("message");
			String gender = request.getParameter("gender");
			
			

			AppointmentBean user = new AppointmentBean();
			user.setDr_id(dr_id);
			user.setEmail(username);
			user.setName(name);
			user.setMob_number(mob_number);
			user.setMessage(message);
			user.setGender(gender);
			user.setAppdate(dateselect);

			// Database Insert Code
			AppoinmentModel appoinmentModel=new AppoinmentModel(); 
		int app_id=	appoinmentModel.bookAppoinment(user);
if(app_id>0){
	request.setAttribute("res", "Congress you are successfully booked appointment !! your Appintment id  :- "+app_id);
	request.getRequestDispatcher("login.jsp").forward(request, response);

}else{
	request.setAttribute("res", "Some error occure , plz try again !!");
	request.getRequestDispatcher("register.jsp").forward(request, response);
}
			
//date 
/*
SimpleDateFormat   dateFormat= new SimpleDateFormat("yyyy-MM-dd");
java.sql.Date date= new java.sql.Date(dateFormat.parse("1016-02-16").getTime()); 
	
	Statement statement= connection.createStatement();
	String sql="insert into dt( Datei) values ( "+(java.sql.Date)date+")";
	//statement.executeUpdate(sql);
	 * 
	 * 
	 * INSERT INTO TABLE_NAME(
date_column
)values(
TO_DATE('06/06/2006', 'mm/dd/yyyy')
)
	 * 
	 * 

If the field is of type datetime or timestamp, you have to use
pstmt.setDate( 1, new java.sql.Date( d1.getTime() );
pstmt.setTimestamp( 1, new java.sql.Timestamp( d1.getTime() );

	
	PreparedStatement preparedStatement= connection.prepareStatement("insert into dt( Datei) values ( ?)");
	preparedStatement.setDate(1,date);
	preparedStatement.executeUpdate();
	
*/
			
		}

	}

}
