package com.bean;

public class ChatBean {

}
