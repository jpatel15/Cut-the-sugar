package com.bean;

public class PataintBean {
	
	private String P_name;
	private String P_mobile_number;
	private String P_gender;
	private String P_Email;//as username
	private int P_id;
	private int status;
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getP_name() {
		return P_name;
	}
	public void setP_name(String p_name) {
		P_name = p_name;
	}
	public String getP_mobile_number() {
		return P_mobile_number;
	}
	public void setP_mobile_number(String p_mobile_number) {
		P_mobile_number = p_mobile_number;
	}
	public String getP_gender() {
		return P_gender;
	}
	public void setP_gender(String p_gender) {
		P_gender = p_gender;
	}
	public String getP_Email() {
		return P_Email;
	}
	public void setP_Email(String p_Email) {
		P_Email = p_Email;
	}
	public int getP_id() {
		return P_id;
	}
	public void setP_id(int p_id) {
		P_id = p_id;
	}
	
}
