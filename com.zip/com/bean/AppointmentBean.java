package com.bean;

public class AppointmentBean {
	private int reg_id;
	private int status;
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	private String dr_id;
	private String name;
	private String appdate;
	private String mob_number;
	private String message;
	private String email;//as username
	public int getReg_id() {
		return reg_id;
	}
	public void setReg_id(int reg_id) {
		this.reg_id = reg_id;
	}

	public String getDr_id(){
		return dr_id;
	}
	public void setDr_id(String dr_id){
		this.dr_id = dr_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAppdate() {
		return appdate;
	}
	public void setAppdate(String appdate) {
		this.appdate = appdate;
	}
	public String getMob_number() {
		return mob_number;
	}
	public void setMob_number(String mob_number) {
		this.mob_number = mob_number;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	private String P_name;
	private String P_mobile_number;
	private String P_gender;
	private String P_Email;//as username
	private int P_id;
	public String getP_name() {
		return P_name;
	}
	public void setP_name(String p_name) {
		P_name = p_name;
	}
	public String getP_mobile_number() {
		return P_mobile_number;
	}
	public void setP_mobile_number(String p_mobile_number) {
		P_mobile_number = p_mobile_number;
	}
	public String getP_gender() {
		return P_gender;
	}
	public void setP_gender(String p_gender) {
		P_gender = p_gender;
	}
	public String getP_Email() {
		return P_Email;
	}
	public void setP_Email(String p_Email) {
		P_Email = p_Email;
	}
	public int getP_id() {
		return P_id;
	}
	public void setP_id(int p_id) {
		P_id = p_id;
	}
	
	private int app_id;
	private String apptime;
	private String gender;
	public int getApp_id() {
		return app_id;
	}
	public void setApp_id(int app_id) {
		this.app_id = app_id;
	}
	public String getApptime() {
		return apptime;
	}
	public void setApptime(String apptime) {
		this.apptime = apptime;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	private String response;
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
}
