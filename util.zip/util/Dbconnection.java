package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Dbconnection {
	
	
	public static Connection getcon() throws ClassNotFoundException, SQLException{
		Connection con=null;
		
		String dbDriver="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/health_companion";
		String username="root";
		String password="root";
		
		Class.forName(dbDriver);
		con=DriverManager.getConnection(url,username,password);
		return con;
		
	}

}
